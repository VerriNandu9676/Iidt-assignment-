import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
import './index.css';


const BASE_URL = 'https://www.googleapis.com/books/v1/volumes';

const fetchBooks = async (searchTerm) => {
  try {
    const formattedTerm = searchTerm.replace(/ /g, '+');
    const response = await axios.get(`${BASE_URL}?q=${formattedTerm}`);
    return response.data.items;
  } catch (error) {
    console.error('Error fetching books:', error);
  }
};

const Book = ({ book }) => {
  const imageUrl = book.volumeInfo?.imageLinks?.thumbnail || '';
  const title = book.volumeInfo?.title;
  const authors = book.volumeInfo?.authors?.join(', ');

  return (
    <div className="book">
      {imageUrl && <img src={imageUrl} alt={title} />}
      <h3>{title}</h3>
      <p>by {authors}</p>
    </div>
  );
};

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [books, setBooks] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const fetchedBooks = await fetchBooks(searchTerm);
      if (fetchedBooks) {
        setBooks(fetchedBooks);
      }
    };
    fetchData();
  }, [searchTerm]);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  return (
    <div className="App">
      <h1>Search books</h1>
      <input
        type="text"
        placeholder="Search Books"
        value={searchTerm}
        onChange={handleSearchChange}
      />
      <button onClick={() => fetchBooks(searchTerm)}>Search</button>
      <div className="book-container">
        {books.map((book, index) => (
          <Book key={book.id} book={book} />
        ))}
      </div>
      {books.length === 0 && <p>No books found. Please try a different search term.</p>}
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
